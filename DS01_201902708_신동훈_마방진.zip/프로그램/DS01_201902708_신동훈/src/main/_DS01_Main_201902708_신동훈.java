package main;

import main.controller.AppController;

/**
 * Created by ShinD on 2022-03-03.
 */
public class _DS01_Main_201902708_신동훈 {


    public static void main(String[] args) {
        AppController appController = new AppController();
        appController.run();
    }
}
