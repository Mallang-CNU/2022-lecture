import controller.AppController;

/**
 * Created by ShinD on 2022/05/03.
 */
public class _DS09_201902708_신동훈 {

	public static void main(String[] args) {
		AppController appController = new AppController();

		appController.run();
	}
}
