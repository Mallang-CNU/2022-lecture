package com.queue;

import com.queue.controller.AppController;

public class _DS10_S2_201802173_홍성빈 {
    public static void main(String[] args) {
        AppController appController = new AppController();
        appController.run();
    }
}
