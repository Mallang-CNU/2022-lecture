package com.queue.view;

import java.util.Scanner;

public class AppView {
    private static Scanner scanner = new Scanner(System.in);

    private AppView() {
    }

    public static void outputLine(String aMessage) {
        System.out.println(aMessage);
    }

    public static void output(String aMessage) {
        System.out.print(aMessage);
    }

    public static char inputChar() {
        String line = AppView.scanner.nextLine().trim();
        while(line.equals("")){
            line = AppView.scanner.nextLine().trim();
        }
        return line.charAt(0);
    }
}
