package com.queue.model;

public class CircularArrayQueue<E> implements Queue<E> {
    private static final int DEFAULT_CAPACITY = 100;

    private int _maxLength;
    private int _frontPosition;
    private int _rearPosition;
    private E[] _elements;

    private int maxLength(){
        return this._maxLength;
    }
    private void setMaxLength(int maxLength){
        this._maxLength = maxLength;
    }
    public int capacity(){
        return this.maxLength()-1;
    }
    private int frontPosition(){
        return this._frontPosition;
    }
    private void setFrontPosition(int frontPosition){
        this._frontPosition = frontPosition;
    }
    private int rearPosition(){
        return this._rearPosition;
    }
    private void setRearPosition(int rearPosition){
        this._rearPosition = rearPosition;
    }
    private E[] elements(){
        return this._elements;
    }
    private void setElements(E[] elements){
        this._elements = elements;
    }

    public CircularArrayQueue(int givenCapacity) {
        this.setFrontPosition(0);
        this.setRearPosition(0);
        this.setMaxLength(givenCapacity+1);
        this.setElements((E[]) new Object[this.maxLength()]);
    }

    @Override
    public int size() {
        if(this.rearPosition()>=this.frontPosition()){
            return this.rearPosition()-this.frontPosition();
        } else{
            return this.rearPosition()-this.frontPosition()+this.maxLength();
        }
    }

    @Override
    public boolean isFull() {
        return this._frontPosition==(this._rearPosition+1)%this.maxLength();
    }

    @Override
    public boolean isEmpty() {
        return this.size()==0;
    }

    @Override
    public E front() {
        if (this.isEmpty()) {
            return null;
        }
        return this.elements()[this.frontPosition()+1];
    }
    @Override
    public E rear() {
        if (this.isEmpty()) {
            return null;
        }
        return this.elements()[this.rearPosition()];
    }

    @Override
    public boolean enQueue(E element) {
        if (this.isFull()) {
            return false;
        }
        else {
            this.setRearPosition((this.rearPosition()+1)%this.maxLength());
            this.elements()[this.rearPosition()] = element;
            return true;
        }
    }

    @Override
    public E deQueue() {
        if (this.isEmpty()) {
            return null;
        } else {
            E element = this.elements()[(this.frontPosition() + 1) % this.maxLength()];
            this.elements()[this.frontPosition()] = null;
            this.setFrontPosition((this.frontPosition() + 1) % this.maxLength());
            return element;
        }
    }

    @Override
    public void clear(){
        this.setFrontPosition(0);
        this.setRearPosition(0);
        for(int i=0;i<this.maxLength();i++){
            this.elements()[i] = null;
        }
    }

    @Override
    public E elementAt(int anOrder){
        if(this.isEmpty()){
            return null;
        }
        else{
            return this.elements()[(this.frontPosition()+1+anOrder)%this.maxLength()];
        }
    }

    public Iterator<E> iterator(){
        return new CircularArrayQueueIterator<E>();
    }

    private class CircularArrayQueueIterator<E> implements Iterator<E>{
        private int _nextOrder;

        private int nextOrder(){
            return this._nextOrder;
        }
        private void setNextOrder(int newNextOrder){
            this._nextOrder = newNextOrder;
        }
        private CircularArrayQueueIterator(){
            this.setNextOrder(0);
        }

        @Override
        public boolean hasNext() {
            return this.nextOrder() < CircularArrayQueue.this.size();
        }

        @Override
        public E next() {
            E nextElement = null;
            if (this.hasNext()) {
                nextElement = (E) CircularArrayQueue.this.elementAt(this.nextOrder());
                this.setNextOrder(this.nextOrder() + 1);
            }
            return nextElement;
        }
    }

}
