import controller.AppController;

/**
 * Created by ShinD on 2022/04/01.
 */
public class _DS05_201902708_신동훈 {

    public static void main(String[] args) {
        AppController appController = new AppController();
        // AppController 가 실질적인 main class 이다.

        appController.run();
        // 여기 main()에서는 앱 실행이 시작되도록 해주는 일이 전부이다.

    }

}
