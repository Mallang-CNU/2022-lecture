package model;

/**
 * Created by ShinD on 2022/04/03.
 */
public interface Iterator<E> {

    boolean hasNext();
    E next();
}
