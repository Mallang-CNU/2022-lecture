import controller.AppController;

/**
 * Created by ShinD on 2022/04/30.
 */
public class _DS08_201902708_신동훈 {
	public static void main(String[] args)
	{
		AppController appController = new AppController();
		appController.run();
	}

}
