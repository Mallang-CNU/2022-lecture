import controller.AppController;

/**
 * Created by ShinD on 2022/04/22.
 */
public class _DS07_201902708_신동훈 {
    public static void main(String[] args) {
        AppController appController = new AppController();
        //AppController 가 실질적인 main class 이다.

        appController.run();
    }
}
