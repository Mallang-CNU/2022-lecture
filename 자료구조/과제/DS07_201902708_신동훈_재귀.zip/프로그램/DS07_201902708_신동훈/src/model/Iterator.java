package model;

/**
 * Created by ShinD on 2022/04/22.
 */
public interface Iterator <T> {
    boolean hasNext();
    T next();
}
