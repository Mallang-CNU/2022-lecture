import java.util.Scanner;

/**
 * Created by ShinD on 2022/04/22.
 */
public class Test {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        int i = sc.nextInt();
        System.out.println(i);
    }
}
