import controller.AppController;

/**
 * Created by ShinD on 2022-05-13.
 */
public class _DS10_S1_201902708_신동훈 {
    public static void main(String[] args) {
        AppController appController = new AppController();
        appController.run();
    }
}
