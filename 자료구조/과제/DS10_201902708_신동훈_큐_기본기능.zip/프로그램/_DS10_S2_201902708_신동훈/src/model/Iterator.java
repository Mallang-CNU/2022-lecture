package model;

/**
 * Created by ShinD on 2022-05-14.
 */
public interface Iterator<E> {
    public boolean hasNext();
    public E next();
}
