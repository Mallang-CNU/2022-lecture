import controller.AppController;

/**
 * Created by ShinD on 2022/03/17.
 */
public class _DS04_Main_201902708_신동훈 {
    public static void main(String[] args) {
        AppController appController = new AppController();
        //controller.AppController 가 실질적인 main class 이다.

        appController.run();
        //여기 main()에서는 앱 실행이 시작되도록 해주는 일이 전부이다.
    }
}
